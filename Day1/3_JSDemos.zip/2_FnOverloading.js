function Hello() {
    console.log("Hello World");
}

function Hello(name) {
    console.log("Hello,", name);
}

Hello();
Hello("Manish");