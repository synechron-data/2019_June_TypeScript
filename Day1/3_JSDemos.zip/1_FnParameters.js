function Hello(name) {
    console.log("Hello,", name);
}

Hello("Manish");
Hello();
Hello("Manish", "Sharma");