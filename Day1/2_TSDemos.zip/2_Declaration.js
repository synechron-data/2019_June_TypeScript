var age;
age = 10;
function add(x, y) {
    return x + y;
}
add(23, 45);
