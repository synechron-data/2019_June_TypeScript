// Implicitly Typed
// var data = 10;
// data = "ABC";

// var data;
// data = 10;
// data = "ABC";

// Explicitly Typed
var age: number;
age = 10;
// age = 'abc';

function add(x: number, y: number) {
    return x + y;
}

add(23, 45);
// add("ABC", true);
