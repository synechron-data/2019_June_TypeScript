var env = "prod";
console.log(env);
if (true) {
    var env_1 = "dev";
    console.log(env_1);
}
var obj = { id: 1 };
console.log(obj.id);
obj.id = 100;
console.log(obj.id);
var arr = [];
console.log(arr);
arr[0] = "Manish";
console.log(arr);
