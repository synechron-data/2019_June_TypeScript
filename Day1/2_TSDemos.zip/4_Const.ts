const env = "prod";
// env = "dev";
console.log(env);

if (true) {
    const env = "dev";
    console.log(env);
}

const obj = { id: 1 };
console.log(obj.id);
obj.id = 100;
// obj = {};
console.log(obj.id);

const arr: string[] = [];
console.log(arr);
arr[0] = "Manish";
console.log(arr);
