var Program = (function () {
    function Program() {
    }
    Program.main = function (args) {
        console.log("Hello, ", args);
    };
    return Program;
}());
Program.main("Synechron");
