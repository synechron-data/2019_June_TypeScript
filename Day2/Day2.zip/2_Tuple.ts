// Tuple - Stores a fixed collection of values of same or varied types, maintaining the sequence

// var arr: number[] = [10, 20, 30, 40, 50];

// var dataArr: (number | string)[] = [10, "ABC"];
// dataArr = ["ABC", 10];
// dataArr = [10, 20, 30, 40];
// dataArr = ["ABC", "XYZ"];

// Tuple
var dataRow: [number, string] = [1, "Manish"];
// dataRow = ["Abhijeet", 2];
// dataRow = [2];
// dataRow = ["Abhijeet"];