function getLength(arg) {
    return arg.length;
}
getLength("abc");
getLength(["abc"]);
getLength([10, 20, 30, 40, 50]);
